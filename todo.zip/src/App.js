import React, { useState, useEffect } from 'react';
import { Container, Typography, Button, List } from '@mui/material';
import TodoItem from './components/todoItem';
import TodoInput from './components/TodoInput';

function TodoApp() {
  const [todos, setTodos] = useState([]);

  // Load todos from local storage
  useEffect(() => {
    const savedTodos = JSON.parse(localStorage.getItem('todos')) || [];
    setTodos(savedTodos);
  }, []);

  // Save todos to local storage whenever they change
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = (title) => {
    const newTodo = { id: Date.now(), title, completed: false };
    setTodos([...todos, newTodo]);
  };

  const toggleComplete = (id) => {
    const updatedTodos = todos?.length && todos?.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    );
    setTodos(updatedTodos);
  };

  const editTodo = (id, newTitle) => {
    const updatedTodos = todos?.length && todos?.map(todo =>
      todo.id === id ? { ...todo, title: newTitle } : todo
    );
    setTodos(updatedTodos);
  };

  const clearTodo = () => {
    const activeTodos = todos?.filter(todo => !todo.completed);
    setTodos(activeTodos);
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" align="center" >
        My Todo List
      </Typography>
      <TodoInput addTodo={addTodo} />
      <List>
        {todos?.length && todos?.map((todo,i) => (
          <TodoItem
            key={todo?.id}
            todo={todo}
            index={i}
            toggleComplete={toggleComplete}
            editTodo={editTodo}
            todos={todos}
          />
        ))}
        {todos?.length ==0 &&
          <span>{" "}NO todo exist</span>
        }
      </List>
      <Button variant="outlined" color="primary" onClick={clearTodo} style={{ marginTop: '10px' }}>
        Clear Line through todo
      </Button>
    </Container>
  );
}

export default TodoApp;

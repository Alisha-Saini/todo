import React, { useState } from 'react';
import { TextField, Button, Box } from '@mui/material';

function TodoInput({ addTodo }) {
  const [title, setTitle] = useState('');

  const handleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title.trim() !== '') {
      addTodo(title);
      setTitle('');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
      <TextField
        label="Enter todo"
        value={title}
        onChange={handleChange}
        fullWidth
      />
      <Button variant="contained" color="success" type="submit">
        Add Todo
      </Button>
    </Box>
  );
}

export default TodoInput;

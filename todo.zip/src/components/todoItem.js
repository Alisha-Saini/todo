import React, { useState } from 'react';
import { ListItem, Checkbox, TextField, IconButton } from '@mui/material';

function TodoItem({ todo, toggleComplete, editTodo ,index,todos}) {
  const [isEditing, setIsEditing] = useState(false);
  const [newTitle, setNewTitle] = useState(todo?.title);

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleChange = (e) => {
    setNewTitle(e.target.value);
  };

  const handleSubmit = () => {
    if (newTitle.trim() !== '') {
      editTodo(todo.id, newTitle);
    }
    setIsEditing(false);
  };

  return (
    <ListItem
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 0',
      }}
    >
        {todos?.length >0 && index + 1 } 
      <Checkbox
        checked={todo.completed}
        onChange={() => toggleComplete(todo.id)}
        color="primary"
      />
      {isEditing ? (
        <TextField
          value={newTitle}
          onChange={handleChange}
          onBlur={handleSubmit}
          onKeyPress={(e) => {
            if (e.key === 'Enter') handleSubmit();
          }}
          autoFocus
          size="small"
          fullWidth
        />
      ) : (
        <span
          onDoubleClick={handleEdit}
          style={{ textDecoration: todo.completed ? 'line-through' : 'none', flexGrow: 1 }}
        >
          {todo?.title}
        </span>
      )}
     
    </ListItem>
  );
}

export default TodoItem;
